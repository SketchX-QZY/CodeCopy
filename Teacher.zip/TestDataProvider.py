import torch
from torchvision import transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
import random
import matplotlib.pyplot as plt

class SuperImageSet(ImageFolder):
    def __init__(self, root, transform=None, addNeg=False):
        super(SuperImageSet, self).__init__(root, transform=transform)
        self.imgs = self.samples
        self.category = False
        self.addNeg = addNeg
        self.dict = dict()
        self.flip = transforms.RandomHorizontalFlip(p=1.0)
        category = len(self.classes)
        total = len(self.samples)
        if category != 1 and total >= category:
            self.category = True
            categoryLength = total // category
            for i in range(category):
                self.dict[self.classes[i]] = self.samples[categoryLength * i:categoryLength * (i + 1)]

    def __getitem__(self, index):
        flipRand = 1
        if self.addNeg:
            flipRand = random.randint(1, 2)
        if self.category:
            items = torch.Tensor()
            targets = []
            for i in range(len(self.classes)):  # edge photo
                path, target = self.dict[self.classes[i]][index]
                sample = self.loader(path)
                if self.transform is not None:
                    sample = self.transform(sample)
                if self.target_transform is not None:
                    target = self.target_transform(target)
                if flipRand == 2:
                    sample = self.flip(sample)
                sample = sample.unsqueeze(0)
                if i == 0:
                    items = sample
                else:
                    items = torch.cat([items, sample], dim=0)  # 2 x 3 x 224 x 224
                targets.append(target)

            if self.addNeg:
                randomId = random.randint(0, self.__len__() - 2)
                if randomId == index:
                    randomId = self.__len__() - 1
                path, target = self.dict[self.classes[1]][randomId]  # add neg photo
                sample = self.loader(path)
                if self.transform is not None:
                    sample = self.transform(sample)
                if self.target_transform is not None:
                    target = self.target_transform(target)
                if flipRand == 2:
                    sample = self.flip(sample)
                sample = sample.unsqueeze(0)
                items = torch.cat([items, sample], dim=0)  # 3 x 3 x 224 x 224
                targets.append(target)

            return items, targets
        else:
            path, target = self.samples[index]
            sample = self.loader(path)
            if self.transform is not None:
                sample = self.transform(sample)
            if self.target_transform is not None:
                target = self.target_transform(target)
            return sample, target

    def __len__(self):
        if self.category:
            return int(len(self.samples) / len(self.classes))
        else:
            return len(self.samples)

def getDataProvider(root, addNeg, shuffle):
    return getDataProviderByDataSet(getDataSet(root, addNeg), shuffle=shuffle)


def getDataProviderByDataSet(dataset, batch_size=16, shuffle=True):
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=0, drop_last=True)
    return dataloader


def getDataSet(root, addNeg=False):
    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    transform = transforms.Compose([
        # transforms.RandomResizedCrop(299, scale=(1., 1.)),  # 随机裁剪224
        # transforms.RandomHorizontalFlip(),  # 50%几率翻转
        transforms.Resize(299),  # 缩放图片，保持长宽比不变，最短边的长为224像素,
        # transforms.CenterCrop(224),  # 从中间切出 224*224的图片
        transforms.ToTensor(),  # 将图片转换为Tensor,归一化至[0,1]
        normalize
    ])
    # '/Users/winkawaks/Desktop/Hello_world/train_t'
    dataset = SuperImageSet(root, transform=transform, addNeg=addNeg)
    return dataset


def getDataSetWithoutTransform(root, addNeg=False):
    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    transform = transforms.Compose([
        transforms.Resize(299),  # 缩放图片，保持长宽比不变，最短边的长为224像素,
        transforms.ToTensor(),  # 将图片转换为Tensor,归一化至[0,1]
        normalize
    ])
    # '/Users/winkawaks/Desktop/Hello_world/train_t'
    dataset = SuperImageSet(root, transform=transform, addNeg=addNeg)
    return dataset


if __name__ == "__main__":
    torch.set_printoptions(profile="full")
    data = getDataProvider('/vol/research/sketch/Hello_world/test', addNeg=True, shuffle=True)
    for jigsaw, label in data:  # photo-pos
        all = jigsaw[0]  # 11 x 3 x 224 x 224
        for i in range(all.shape[0]):
            img = all[i]
            plt.imshow(img.permute(1, 2, 0))
            plt.show()
        break
