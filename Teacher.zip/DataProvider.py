import torch
from torchvision import transforms
from torchvision.datasets import ImageFolder
from torch.utils.data import DataLoader
from PIL import ImageFilter
import random
import numpy as np
import matplotlib.pyplot as plt


class SuperImageSet(ImageFolder):
    def __init__(self, root, transform=None, jigsawNum=3, edge=True):
        super(SuperImageSet, self).__init__(root, transform=transform)
        self.imgs = self.samples
        self.category = False
        self.edge = edge
        self.dict = dict()
        self.jigsawNum = jigsawNum
        self.toPIL = transforms.ToPILImage()
        normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])

        category = len(self.classes)  # ['test_edge', 'test_photo']
        total = len(self.samples)
        if category != 1 and total >= category:
            self.category = True
            categoryLength = total // category
            for i in range(category):
                self.dict[self.classes[i]] = self.samples[categoryLength * i:categoryLength * (i + 1)]

        color_transform = [get_color_distortion(), PILRandomGaussianBlur()]
        trans = []
        randomresizedcrop = transforms.RandomResizedCrop(
            299,
            scale=(0.5, 1),
        )
        trans.extend([transforms.Compose([
            randomresizedcrop,
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.Compose(color_transform),
            transforms.ToTensor(),
            normalize])] * 2)
        self.trans = trans

    def __getitem__(self, index):
        if self.category:
            items = []
            targets = []

            for i in range(len(self.classes)):    # ['test_edge', 'test_photo']
                path, target = self.dict[self.classes[i]][index]
                sample = self.loader(path)
                if self.transform is not None:
                    sample = self.transform(sample)
                if self.target_transform is not None:
                    target = self.target_transform(target)

                sample = pil_to_tensor(sample)
                sample = getBoundingBox(sample)  # 3 x 224 x 224
                items.append(sample)
                targets.append(target)
            if random.randint(1, 2) == 1 or not self.edge:
                img = items[1] / 255
            else:
                img = items[0] / 255
            img = self.toPIL(img)
            imgs = list(map(lambda trans: trans(img), self.trans))

            return index, imgs
        else:
            path, target = self.samples[index]
            sample = self.loader(path)
            if self.transform is not None:
                sample = self.transform(sample)
            if self.target_transform is not None:
                target = self.target_transform(target)
            return sample, target

    def __len__(self):
        if self.category:
            return int(len(self.samples) / len(self.classes))
        else:
            return len(self.samples)

    def put_image_on_canvas(self, data, orig_img_size, percent=0.78, if_random=False):
        if if_random:  # 0.95 ~ 1
            percent = np.random.uniform(percent, 1.0)

        h, w = data.shape[1], data.shape[2]
        canvas = torch.ones(3, orig_img_size, orig_img_size, dtype=torch.uint8) * 255
        longer = int(np.floor(percent * orig_img_size))

        # 把长的边变为orig_img_size
        if h >= w:  # 把高变为orig_img_size
            ratio = h / float(w)
            y = int(np.floor(longer / ratio))
            resize = transforms.Resize((longer, y))
            temp = resize(data)  # 3 x longer x y
            offset_long = int(np.floor((orig_img_size - longer) / 2.0))
            offset_short = int(np.floor((orig_img_size - y) / 2.0))
            canvas[:, offset_long:offset_long + longer, offset_short:offset_short + y] = temp
        else:  # 把宽变为orig_img_size
            ratio = w / float(h)
            x = int(np.floor(longer / ratio))
            resize = transforms.Resize((x, longer))
            temp = resize(data)  # 3 x x x longer
            offset_long = int(np.floor((orig_img_size - longer) / 2.0))
            offset_short = int(np.floor((orig_img_size - x) / 2.0))
            canvas[:, offset_short:offset_short + x, offset_long:offset_long + longer] = temp
        return canvas

class PILRandomGaussianBlur(object):
    def __init__(self, p=0.5, radius_min=0.1, radius_max=2.):
        self.prob = p
        self.radius_min = radius_min
        self.radius_max = radius_max

    def __call__(self, img):
        do_it = np.random.rand() <= self.prob
        if not do_it:
            return img

        return img.filter(
            ImageFilter.GaussianBlur(
                radius=random.uniform(self.radius_min, self.radius_max)
            )
        )


def get_color_distortion(s=1.0):
    # s is the strength of color distortion.
    color_jitter = transforms.ColorJitter(0.8*s, 0.8*s, 0.8*s, 0.2*s)
    rnd_color_jitter = transforms.RandomApply([color_jitter], p=0.8)
    rnd_gray = transforms.RandomGrayscale(p=0.2)
    color_distort = transforms.Compose([rnd_color_jitter, rnd_gray])
    return color_distort


def pil_to_tensor(pic):
    # handle PIL Image
    img = torch.as_tensor(np.array(pic))
    img = img.view(pic.size[1], pic.size[0], len(pic.getbands()))
    # put it from HWC to CHW format
    img = img.permute((2, 0, 1))
    return img

def rgb_jittering(im):
    for ch in range(3):
        im[ch, :, :] += np.random.randint(-2, 2)
    im[im > 255] = 255
    im[im < 0] = 0
    return im

def getBoundingBox(data):
    temp = torch.round(rgb2gray(data))
    temp[temp >= 255] = 255
    a = np.where(temp != 255)
    if a[0].size == 0 or a[1].size == 0:
        return data
    if min(np.max(a[0]) - np.min(a[0]), np.max(a[1]) - np.min(a[1])) <= 8:
        return data
    bbox = data[:, np.min(a[0]):np.max(a[0]), np.min(a[1]):np.max(a[1])]
    return bbox

def rgb2gray(rgb):
    r, g, b = rgb[0, :, :], rgb[1, :, :], rgb[2, :, :]
    gray = 0.2989 * r + 0.5870 * g + 0.1140 * b
    return gray

def getDataProvider(root, shuffle):
    return getDataProviderByDataSet(getDataSet(root, jigsawNum=4), shuffle=shuffle)


def getDataProviderByDataSet(dataset, batch_size=16, shuffle=True):
    # dataloader是一个可迭代的对象，意味着我们可以像使用迭代器一样使用它 或者 or batch_datas, batch_labels in dataloader:
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=0, drop_last=True)
    return dataloader


def getDataSet(root, jigsawNum=4, edge=True):
    # '/Users/winkawaks/Desktop/Hello_world/train_t'
    dataset = SuperImageSet(root, jigsawNum=jigsawNum, edge=edge)
    return dataset


def getDataSetWithoutTransform(root, addNeg=False):
    normalize = transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    transform = transforms.Compose([
        transforms.ToTensor(),  # 将图片转换为Tensor,归一化至[0,1]
        normalize
    ])
    # '/Users/winkawaks/Desktop/Hello_world/train_t'
    dataset = SuperImageSet(root, transform=transform)
    return dataset


if __name__ == "__main__":
    torch.set_printoptions(profile="full")
    data = getDataProvider('/Users/winkawaks/Desktop/Hello_world/test_jigsaw/', True)
    show = True
    for index, imgs in data:  # photo-pos
        if show:
            show = False
            imgList = imgs[0]
            imgList1 = imgs[1]
            print(len(imgList))
            print(len(imgList1))
            for i in range(2):
                print(index)
                plt.imshow(imgList[i].permute(1, 2, 0))
                plt.show()
                plt.imshow(imgList1[i].permute(1, 2, 0))
                plt.show()
            exit(0)
        # print(jigsaw.size())
        # print(label.size())
