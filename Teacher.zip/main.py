import copy
import datetime
import os
import sys

import opts
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as f
import torch.optim
import torch.optim as optim
import torch.utils.data
import torchvision.models as models
from scipy.sparse import csr_matrix
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import traceback

import TestDataProvider as test_provider
import DataProvider as provider

######################################### Settings ###########################################
jigsawNum = 4
init_lr = 1e-3
best_cvpr_sbir_acc_multi = 0
best_cvpr_sbir_acc_single = 0

singleFile = 'single.pt'
multiFile = 'multi.pt'
endFile = 'end.pt'

bestLog = 'best.txt'
sbirLog = 'sbir.txt'

class ModelType(Enum):
    Cluster = 0
    MATCHING = 1

class InceptionX(models.Inception3):

    def __init__(
            self,
            num_classes: int = 1000,
            aux_logits: bool = True,
            transform_input: bool = False,
            inception_blocks=None,
            init_weights=None,
            opt=None
    ):
        super(InceptionX, self).__init__(num_classes, aux_logits, transform_input, inception_blocks, init_weights)
        self.l2norm = True
        self.modelType = ModelType.MATCHING
        self.opt = opt

        self.projection_head = nn.Sequential(
            nn.Linear(2048, 1000),
            nn.BatchNorm1d(1000),
            nn.ReLU(inplace=True),
            nn.Linear(1000, opt['feat_dim']),
        )

        self.prototypes = nn.Linear(opt['feat_dim'], opt['nmb_prototypes'], bias=False)
        self.add_module("prototypes", self.prototypes)

    def setType(self, type):
        self.modelType = type

    def forward(self, x):
        if self.modelType == ModelType.Cluster:
            return self.forward_cluster(x)
        elif self.modelType == ModelType.MATCHING:
            return self.normFeature(x)

    def forward_head(self, x):
        if self.projection_head is not None:
            x = self.projection_head(x)

        if self.l2norm:
            x = nn.functional.normalize(x, dim=1, p=2)

        if self.prototypes is not None:
            return x, self.prototypes(x)
        return x

    # jigsaw + edge + posPhoto + negPhoto
    def forward_cluster(self, x):
        if not isinstance(x, list):
            x = [x]
        idx_crops = torch.cumsum(torch.unique_consecutive(torch.tensor([inp.shape[-1] for inp in x]), return_counts=True)[1], 0)
        start_idx = 0
        output = torch.Tensor()
        for end_idx in idx_crops:
            _out = self.extractFeature(torch.cat(x[start_idx: end_idx]).cuda(opt['CLUSTER_GPU'], non_blocking=True))
            if start_idx == 0:
                output = _out
            else:
                output = torch.cat((output, _out))
            start_idx = end_idx
        return self.forward_head(output)

    def extractFeature(self, x):
        # N x 3 x 299 x 299
        x = self.Conv2d_1a_3x3(x)
        # N x 32 x 149 x 149
        x = self.Conv2d_2a_3x3(x)
        # N x 32 x 147 x 147
        x = self.Conv2d_2b_3x3(x)
        # N x 64 x 147 x 147
        x = self.maxpool1(x)
        # N x 64 x 73 x 73
        x = self.Conv2d_3b_1x1(x)
        # N x 80 x 73 x 73
        x = self.Conv2d_4a_3x3(x)
        # N x 192 x 71 x 71
        x = self.maxpool2(x)
        # N x 192 x 35 x 35
        x = self.Mixed_5b(x)
        # N x 256 x 35 x 35
        x = self.Mixed_5c(x)
        # N x 288 x 35 x 35
        x = self.Mixed_5d(x)
        # N x 288 x 35 x 35
        x = self.Mixed_6a(x)
        # N x 768 x 17 x 17
        x = self.Mixed_6b(x)
        # N x 768 x 17 x 17
        x = self.Mixed_6c(x)
        # N x 768 x 17 x 17
        x = self.Mixed_6d(x)
        # N x 768 x 17 x 17
        x = self.Mixed_6e(x)
        # N x 768 x 17 x 17

        # N x 768 x 17 x 17
        x = self.Mixed_7a(x)
        # N x 1280 x 8 x 8
        x = self.Mixed_7b(x)
        # N x 2048 x 8 x 8
        x = self.Mixed_7c(x)
        # N x 2048 x 8 x 8
        # Adaptive average pooling
        x = self.avgpool(x)
        # N x 2048 x 1 x 1
        x = self.dropout(x)
        # N x 2048 x 1 x 1
        x = torch.flatten(x, 1)
        # N x 2048

        return x

    def normFeature(self, x):
        x = self.extractFeature(x)
        feature = f.normalize(x, dim=1, p=2)
        return feature

def inception(type, opt, **kwargs):
    model_urls = {
        # Inception v3 ported from TensorFlow
        'inception_v3_google': 'https://download.pytorch.org/models/inception_v3_google-0cc3c7bd.pth',
    }
    if 'transform_input' not in kwargs:
        kwargs['transform_input'] = False
    if 'aux_logits' not in kwargs:
        kwargs['aux_logits'] = False

    original_aux_logits = kwargs['aux_logits']
    kwargs['aux_logits'] = False
    kwargs['init_weights'] = True
    model = InceptionX(opt=opt, **kwargs)
    model.setType(type)

    model.aux_logits = False
    model.AuxLogits = None
    return model

# 1150 x 1024       1150 x 1024
def evaluate_SBIR(query_feat, gallery_feat, type='single'):
    def calc_acc(dist):
        pair_sort = torch.argsort(dist)
        count_1 = 0
        count_5 = 0
        count_10 = 0
        query_num = pair_sort.shape[0]
        for idx1 in range(0, query_num):
            if idx1 in pair_sort[idx1, 0:1]:
                count_1 = count_1 + 1
            if idx1 in pair_sort[idx1, 0:5]:
                count_5 = count_5 + 1
            if idx1 in pair_sort[idx1, 0:10]:
                count_10 = count_10 + 1
        acc_1 = count_1 / float(query_num)
        acc_5 = count_5 / float(query_num)
        acc_10 = count_10 / float(query_num)

        return [acc_1, acc_5, acc_10]

    if type == 'single':
        dist_feat = torch.cdist(query_feat, gallery_feat)
        return calc_acc(dist_feat)
    elif type == 'multi':
        feat_dim = query_feat.shape[1]  # 1024
        que_feat = query_feat.reshape([-1, 10, feat_dim])  # 115 x 10 x 1024
        gal_feat = gallery_feat.reshape([-1, 10, feat_dim])  # 115 x 10 x 1024
        que_num = query_feat.shape[0]  # 1150
        gal_num = gallery_feat.shape[0]  # 1150
        dist_feat = torch.zeros((10, que_num // 10, gal_num // 10))  # 10 x 115 x 115
        for i in range(10):
            dist_feat[i, :, :] = torch.cdist(que_feat[:, i, :], gal_feat[:, i, :])

        dist_feat_mean = dist_feat.mean(axis=0)
        return calc_acc(dist_feat_mean)
    else:
        assert 1 == 2

def do_sbir_test(model, test_sketch, test_photo, opt):
    # single_test_sbir_sketch = extract_feature_sbir(model, do_singleview_crop(test_sketch, opt), opt)
    # single_test_sbir_photo = extract_feature_sbir(model, do_singleview_crop(test_photo, opt), opt)
    # sbir_single_acc = evaluate_SBIR(single_test_sbir_sketch, single_test_sbir_photo, 'single')
    # multi_test_sbir_sketch = extract_feature_sbir(model, do_multiview_crop(test_sketch, opt), opt)
    # multi_test_sbir_photo = extract_feature_sbir(model, do_multiview_crop(test_photo, opt), opt)
    # sbir_multi_acc = evaluate_SBIR(multi_test_sbir_sketch, multi_test_sbir_photo, 'multi')

    single_test_sbir_sketch = extract_feature_sbir(model, test_sketch, opt)
    single_test_sbir_photo = extract_feature_sbir(model, test_photo, opt)
    sbir_single_acc = evaluate_SBIR(single_test_sbir_sketch, single_test_sbir_photo, 'single')
    sbir_multi_acc = [0, 0, 0]
    return sbir_single_acc, sbir_multi_acc

def extract_feature_sbir(model, data, opt):
    allFeatures = None
    batchSize = 16
    batchCount = data.shape[0] // batchSize

    for i in range(0, batchCount):
        output = model.normFeature(data[i * batchSize:(i + 1) * batchSize, ...].cuda(opt['MATCHING_GPU'], non_blocking=True))
        if allFeatures is None:
            allFeatures = output
        else:
            allFeatures = torch.cat([allFeatures, output], dim=0)
    return allFeatures

def do_singleview_crop(data, opt):
    crop_img_size = 224
    orig_img_size = 256

    n = data.shape[0]
    y_cen = int((orig_img_size - crop_img_size) * 0.5)
    x_cen = int((orig_img_size - crop_img_size) * 0.5)
    x = torch.zeros((n, 3, crop_img_size, crop_img_size)).cuda(opt['MATCHING_GPU'])
    for idx in range(n):
        x[idx] = data[idx, :, y_cen:y_cen + crop_img_size, x_cen:x_cen + crop_img_size]
    return x


# # 115 x 3 x 256 x256 -> 1150 x 3 x 224 x 224
def do_multiview_crop(data, opt):
    crop_img_size = 224
    orig_img_size = 256

    n = data.shape[0]
    xs = [0, 0, orig_img_size - crop_img_size, orig_img_size - crop_img_size]  # 0, 0, 32, 32
    ys = [0, orig_img_size - crop_img_size, 0, orig_img_size - crop_img_size]  # 0, 32, 0, 32

    new_data = torch.zeros(n * 10, 3, crop_img_size, crop_img_size).cuda(opt['MATCHING_GPU'])
    y_cen = int((orig_img_size - crop_img_size) * 0.5)  # 16
    x_cen = int((orig_img_size - crop_img_size) * 0.5)  # 16

    for i in range(n):  # 115
        for (k, (x, y)) in enumerate(zip(xs, ys)):
            new_data[i * 10 + k, :, :, :] = data[i, :, y:y + crop_img_size, x:x + crop_img_size]  # 4个角
        new_data[i * 10 + 4, :, :, :] = data[i, :, y_cen:y_cen + crop_img_size, x_cen:x_cen + crop_img_size]  # 中心

        for k in range(5):  # 翻转
            new_data[i * 10 + k + 5, :, :, :] = flip(new_data[i * 10 + k, :, :, :], -1)

    return new_data


def flip(x, dim):
    indices = [slice(None)] * x.dim()
    indices[dim] = torch.arange(x.size(dim) - 1, -1, -1, device=x.device)
    return x[tuple(indices)]

class TripletLossFunc(nn.Module):
    def __init__(self, margin):
        super(TripletLossFunc, self).__init__()
        self.margin = margin
        return

    def forward(self, anchor, pos, neg):
        posDist = anchor - pos
        posAll = torch.sum(torch.square(posDist), 1)

        negDist = anchor - neg
        negAll = torch.sum(torch.square(negDist), 1)

        loss = torch.mean(torch.relu(self.margin + posAll - negAll))
        return loss


def guassian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    """计算Gram/核矩阵
    source: sample_size_1 * feature_size 的数据
    target: sample_size_2 * feature_size 的数据
    kernel_mul: 这个概念不太清楚，感觉也是为了计算每个核的bandwith
    kernel_num: 表示的是多核的数量
    fix_sigma: 表示是否使用固定的标准差

		return: (sample_size_1 + sample_size_2) * (sample_size_1 + sample_size_2)的
						矩阵，表达形式:
						[	K_ss K_st
							K_ts K_tt ]
    """
    n_samples = int(source.size()[0]) + int(target.size()[0])
    total = torch.cat([source, target], dim=0)  # 合并在一起

    total0 = total.unsqueeze(0).expand(int(total.size(0)), \
                                       int(total.size(0)), \
                                       int(total.size(1)))
    total1 = total.unsqueeze(1).expand(int(total.size(0)), \
                                       int(total.size(0)), \
                                       int(total.size(1)))
    L2_distance = ((total0 - total1) ** 2).sum(2)  # 计算高斯核中的|x-y|

    # 计算多核中每个核的bandwidth
    if fix_sigma:
        bandwidth = fix_sigma
    else:
        bandwidth = torch.sum(L2_distance.data) / (n_samples ** 2 - n_samples)
    bandwidth /= kernel_mul ** (kernel_num // 2)
    bandwidth_list = [bandwidth * (kernel_mul ** i) for i in range(kernel_num)]

    # 高斯核的公式，exp(-|x-y|/bandwith)
    kernel_val = [torch.exp(-L2_distance / bandwidth_temp) for \
                  bandwidth_temp in bandwidth_list]

    return sum(kernel_val)  # 将多个核合并在一起


def mmd(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    batch_size = int(source.size()[0])
    kernels = guassian_kernel(source, target,
                              kernel_mul=kernel_mul,
                              kernel_num=kernel_num,
                              fix_sigma=fix_sigma)
    XX = kernels[:batch_size, :batch_size]  # Source<->Source
    YY = kernels[batch_size:, batch_size:]  # Target<->Target
    XY = kernels[:batch_size, batch_size:]  # Source<->Target
    YX = kernels[batch_size:, :batch_size]  # Target<->Source
    loss = torch.mean(XX + YY - XY - YX)  # 这里是假定X和Y的样本数量是相同的
    # 当不同的时候，就需要乘上上面的M矩阵
    return loss

def get_indices_sparse(data):
    cols = np.arange(data.size)
    M = csr_matrix((cols, (data.ravel(), cols)), shape=(int(data.max()) + 1, data.size))
    return [np.unravel_index(row.data, data.shape) for row in M]

def cluster_memory(model, local_memory_index, local_memory_embeddings, size_dataset, opt, nmb_kmeans_iters=10):
    gpu = opt['CLUSTER_GPU']
    nmb_prototypes = opt['nmb_prototypes']
    feat_dim = opt['feat_dim']
    crops = [0, 1]
    j = 0
    assignments = -100 * torch.ones(1, size_dataset).long()
    with torch.no_grad():

        # run distributed k-means

        # init centroids with elements from memory bank of rank 0
        centroids = torch.empty(nmb_prototypes, feat_dim).cuda(gpu, non_blocking=True)

        random_idx = torch.randperm(len(local_memory_embeddings[j]))[:nmb_prototypes]
        assert len(random_idx) >= nmb_prototypes, "please reduce the number of centroids"
        centroids = local_memory_embeddings[j][random_idx]

        for n_iter in range(nmb_kmeans_iters + 1):
            # E step
            dot_products = torch.mm(local_memory_embeddings[j], centroids.t())
            _, local_assignments = dot_products.max(dim=1)

            # finish
            if n_iter == nmb_kmeans_iters:
                break

            # M step
            where_helper = get_indices_sparse(local_assignments.cpu().numpy())
            counts = torch.zeros(nmb_prototypes).cuda(gpu, non_blocking=True).int()
            emb_sums = torch.zeros(nmb_prototypes, feat_dim).cuda(gpu, non_blocking=True)
            for k in range(len(where_helper)):
                if len(where_helper[k][0]) > 0:
                    emb_sums[k] = torch.sum(
                        local_memory_embeddings[j][where_helper[k][0]],
                        dim=0,
                    )
                    counts[k] = len(where_helper[k][0])

            mask = counts > 0
            centroids[mask] = emb_sums[mask] / counts[mask].unsqueeze(1)

            # normalize centroids
            centroids = nn.functional.normalize(centroids, dim=1, p=2)

        getattr(model, "prototypes").weight.copy_(centroids)

        # gather the assignments
        assignments_all = [local_assignments]
        assignments_all = torch.cat(assignments_all).cpu()

        # gather the indexes
        indexes_all = [local_memory_index]
        indexes_all = torch.cat(indexes_all).cpu()

        # log assignments
        assignments[0][indexes_all] = assignments_all

        # next memory bank to use
        j = (j + 1) % len(crops)

    return assignments

def init_memory(dataloader, model, opt):
    gpu = opt['CLUSTER_GPU']
    size_memory_per_process = len(dataloader) * opt['batch_size']
    crops = [0, 1]
    local_memory_index = torch.zeros(size_memory_per_process).long().cuda(gpu)
    local_memory_embeddings = torch.zeros(len(crops), size_memory_per_process, opt['feat_dim']).cuda(gpu)
    start_idx = 0
    with torch.no_grad():
        for index, inputs in dataloader:
            nmb_unique_idx = inputs[0].size(0)
            index = index.cuda(gpu, non_blocking=True)

            # get embeddings
            outputs = []
            for crop_idx in crops:
                inp = inputs[crop_idx].cuda(gpu, non_blocking=True)
                outputs.append(model(inp)[0])

            # fill the memory bank
            local_memory_index[start_idx : start_idx + nmb_unique_idx] = index
            for mb_idx, embeddings in enumerate(outputs):
                local_memory_embeddings[mb_idx][
                    start_idx : start_idx + nmb_unique_idx
                ] = embeddings
            start_idx += nmb_unique_idx
    return local_memory_index, local_memory_embeddings

def evalMainModel(tripletLoader, main_model, epoch_id, opt):
    main_model.eval()
    with torch.no_grad():
        theTime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        allPhotos = None
        allEdges = None

        for fullData, target in tripletLoader:
            batchEdges = fullData[:, 0, ...]  # 16 x 3 x 256 x 256
            batchPhotos = fullData[:, 1, ...]  # 16 x 3 x 256 x 256
            if allEdges is None:
                allEdges = batchEdges
            else:
                allEdges = torch.cat([allEdges, batchEdges], dim=0)
            if allPhotos is None:
                allPhotos = batchPhotos
            else:
                allPhotos = torch.cat([allPhotos, batchPhotos], dim=0)

        cvpr_fs, cvpr_fm = do_sbir_test(main_model, allEdges, allPhotos, opt)

        global best_cvpr_sbir_acc_single, best_cvpr_sbir_acc_multi
        if cvpr_fm[0] > best_cvpr_sbir_acc_multi and epoch_id > 0.7 * opt['epoch']:
            best_cvpr_sbir_acc_multi = cvpr_fm[0]
            saveCheckpoint(main_model, multiFile, opt)

        if cvpr_fs[0] > best_cvpr_sbir_acc_single and epoch_id > 0.7 * opt['epoch']:
            best_cvpr_sbir_acc_single = cvpr_fs[0]
            saveCheckpoint(main_model, singleFile, opt)

        with open(opt['home'] + opt['logFolder'] + sbirLog, 'a') as text_file:
            text_file.write(
                "Time: [%s], Epoch: [%d], f_1: %.4f, f_5: %.4f, f_10: %.4f, f_1m: %.4f, f_5m: %.4f, f_10m: %.4f \n" % (
                    theTime, epoch_id, cvpr_fs[0], cvpr_fs[1], cvpr_fs[2], cvpr_fm[0], cvpr_fm[1], cvpr_fm[2]))

        with open(opt['home'] + opt['logFolder'] + bestLog, 'a') as text_file:
            text_file.write("Time: [%s], Epoch: [%d], classify: %.4f,cvpr_s: %.4f,cvpr_m: %.4f\n" % (
                theTime, epoch_id, 0, best_cvpr_sbir_acc_single, best_cvpr_sbir_acc_multi))


def start(trainLoader, matchTrainLoader, testLoader, cluster_model, main_model, cluster_copy_model, cluster_opt,
          main_opt,
          cluster_loss_f, triplet_loss_f, opt):
    local_memory_index, local_memory_embeddings = init_memory(trainLoader, cluster_model, opt)

    executor = ThreadPoolExecutor(max_workers=4)

    # use for copy cluster model feature
    for epoch_id in range(opt['epoch']):
        try:
            # train cluster
            threadTask = executor.submit(train_cluster, trainLoader, cluster_model, cluster_opt, local_memory_index,
                                         local_memory_embeddings, cluster_loss_f, opt, epoch_id)
            if epoch_id == opt['warmup']:
                for realParam, param in zip(cluster_model.parameters(), main_model.parameters()):
                    param.data = copy.deepcopy(realParam.data).cuda(opt['MATCHING_GPU'])
            if epoch_id > opt['warmup']:
                # train matching after warm up
                train_main(main_model, cluster_model, cluster_copy_model, main_opt, matchTrainLoader, triplet_loss_f, opt, epoch_id)

            log = threadTask.result()
            print(log)
        except Exception as e:
            traceback.print_exc()
            print(e)
            print('error!!!')

        # eval main model
        evalMainModel(testLoader, main_model, epoch_id, opt)

def train_main(main_model, cluster_model, cluster_copy_model, main_opt, matchTrainLoader, triplet_loss_f, opt, epoch_id):
    main_model.train()
    main_model.setType(ModelType.MATCHING)

    for i, (fullData, batchLabel) in enumerate(matchTrainLoader):
        allEdges = fullData[:, 0, ...]  # 16 x 3 x 224 x 224
        allPosPhotos = fullData[:, 1, ...]  # 16 x 3 x 224 x 224
        allNegPhotos = fullData[:, 2, ...]  # 16 x 3 x 224 x 224
        all = torch.cat([allEdges, allPosPhotos, allNegPhotos], dim=0)
        target_feature = None

        with torch.no_grad():
            cluster_copy_model.train()
            cluster_copy_model.setType(ModelType.MATCHING)

            # 将cluster model weight同步到copy cluster model weight
            for realParam, param in zip(cluster_model.parameters(), cluster_copy_model.parameters()):
                param.data = copy.deepcopy(realParam.data).cuda(opt['CLUSTER_GPU'])
            data_cluster = all.cuda(opt['CLUSTER_GPU'], non_blocking=True)
            target_feature = cluster_copy_model(data_cluster).cuda(opt['MATCHING_GPU'])

        all = all.cuda(opt['MATCHING_GPU'], non_blocking=True)  # 48 x 3 x 224 x 224
        allFeatures = main_model(all)  # 48 x 1024
        anchor, pos, neg = allFeatures.chunk(3, 0)
        triplet_loss = triplet_loss_f(anchor, pos, neg)
        mmd_loss = mmd(allFeatures, target_feature)
        loss = triplet_loss + mmd_loss
        main_opt.zero_grad()
        loss.backward()
        main_opt.step()

        print('epoch-', epoch_id, '-iter-', i, '  loss: ', loss.item())


def train_cluster(loader, model, optimizer, local_memory_index, local_memory_embeddings, cluster_loss_f, opt, epoch_id):
    model.train()
    model.setType(ModelType.Cluster)

    assignments = cluster_memory(model, local_memory_index, local_memory_embeddings, len(loader.dataset), opt)
    start_idx = 0
    for it, (idx, inputs) in enumerate(loader):
        # ============ multi-res forward passes ... ============
        emb, output = model(inputs)
        emb = emb.detach()
        bs = inputs[0].size(0)

        # ============ deepcluster-v2 loss ... ============
        scores = output / 0.1
        targets = assignments[0][idx].repeat(sum([2])).cuda(opt['CLUSTER_GPU'], non_blocking=True)
        loss = cluster_loss_f(scores, targets)

        # ============ backward and optim step ... ============
        optimizer.zero_grad()
        loss.backward()
        # print(loss.item())

        # cancel some gradients
        for name, p in model.named_parameters():
            if "prototypes" in name:
                p.grad = None
        optimizer.step()

        # ============ update memory banks ... ============
        local_memory_index[start_idx : start_idx + bs] = idx
        for i, crop_idx in enumerate([0, 1]):
            local_memory_embeddings[i][start_idx : start_idx + bs] = \
                emb[crop_idx * bs : (crop_idx + 1) * bs]
        start_idx += bs
    return str(epoch_id) + ' cluster finish'

def getOptim(model, lr):
    torch_optimizer = optim.SGD(model.parameters(), lr, momentum=0.9)
    return torch_optimizer

def checkAllFiles(opt):
    checkFolder(opt['ckptFolder'], opt)
    checkFolder(opt['logFolder'], opt)
    checkCkpt(singleFile, opt)
    checkCkpt(multiFile, opt)
    checkCkpt(endFile, opt)
    checkLog(bestLog, opt)
    checkLog(sbirLog, opt)

def checkFolder(folder, opt):
    folder = opt['home'] + folder
    print('folder ' + folder)
    if not os.path.exists(folder):
        os.makedirs(folder)

def checkCkpt(file, opt):
    file = opt['home'] + opt['ckptFolder'] + file
    print('file ' + file)
    if os.path.exists(file):
        os.remove(file)
    os.mknod(file)

def checkLog(file, opt):
    file = opt['home'] + opt['logFolder'] + file
    if not os.path.exists(file):
        os.mknod(file)

def saveCheckpoint(model, url, opt):
    print('saveCheckpoint: ' + str(url))
    torch.save(model.state_dict(), opt['home'] + opt['ckptFolder'] + url)

def main(opt):
    trainSet = provider.getDataSet(opt['trainset_path'], jigsawNum=jigsawNum, edge=True)
    trainLoader = provider.getDataProviderByDataSet(trainSet, batch_size=opt['batch_size'])

    matchingTrainSet = test_provider.getDataSet(opt['trainset_path'], addNeg=True)
    matchTrainLoader = test_provider.getDataProviderByDataSet(matchingTrainSet, batch_size=opt['batch_size'], shuffle=True)

    tripletSet = test_provider.getDataSetWithoutTransform(opt['matching_test_path'])
    testLoader = test_provider.getDataProviderByDataSet(tripletSet, batch_size=16, shuffle=False)

    cluster_model = inception(ModelType.Cluster, opt).cuda(opt['CLUSTER_GPU'])
    main_model = inception(ModelType.MATCHING, opt).cuda(opt['MATCHING_GPU'])
    cluster_copy_model = copy.deepcopy(cluster_model).cuda(opt['CLUSTER_GPU'])

    cluster_opt = getOptim(cluster_model, init_lr)
    main_opt = getOptim(main_model, init_lr)

    cluster_loss_f = nn.CrossEntropyLoss(ignore_index=-100).cuda(opt['CLUSTER_GPU'])
    triplet_loss_f = TripletLossFunc(margin=0.1).cuda(opt['MATCHING_GPU'])

    checkAllFiles(opt)

    start(trainLoader, matchTrainLoader, testLoader, cluster_model, main_model, cluster_copy_model, cluster_opt, main_opt,
                         cluster_loss_f, triplet_loss_f, opt)

    saveCheckpoint(main_model, endFile, opt)

if __name__ == "__main__":
    opt = opts.parse_opt()
    opt = vars(opt)
    main(opt)
