import argparse

# home = '/vol/research/sketch/Constrastive/Cluster/'
# ckptFolder = 'ckpt_cluster/'
# logFolder = 'log_cluster/'
# feat_dim = 256
# nmb_prototypes = 512
# batch_size = 128
# CLUSTER_GPU = 0
# MATCHING_GPU = 1
# epoch = 200


def parse_opt():
    parser = argparse.ArgumentParser()
    # Overall settings
    parser.add_argument(
        '--home',
        type=str,
        default='/vol/research/sketch/Meta/Baseline/Framework/InceptionV3/')
    parser.add_argument(
        '--ckptFolder', '-ckpt',
        type=str,
        default='ckpt_cluster/')
    parser.add_argument(
        '--logFolder', '-log',
        type=str,
        default='log_cluster/')
    parser.add_argument(
        '--trainset_path',
        type=str,
        default='/vol/research/sketch/Data/Shoe')
    parser.add_argument(
        '--matching_test_path',
        type=str,
        default='/vol/research/sketch/Data/ShoeEdgeTest')

    parser.add_argument(
        '--feat_dim',
        type=int,
        default=256)
    parser.add_argument(
        '--nmb_prototypes',
        type=int,
        default=512)
    parser.add_argument(
        '--batch_size',
        type=int,
        default=96)
    parser.add_argument(
        '--CLUSTER_GPU',
        type=int,
        default=0)
    parser.add_argument(
        '--MATCHING_GPU',
        type=int,
        default=1)
    parser.add_argument(
        '--epoch',
        type=int,
        default=200)

    parser.add_argument(
        '--warmup',
        type=int,
        default=10)

    args = parser.parse_args()

    return args
